let nomeFilme = "Batman";

if (nomeFilme === "Coringa") {
  console.log("É o filme do Coringa");
} else if (nomeFilme === "Batman") {
  console.log("É o filme do Batman");
} else {
  console.log("É outro filme");
}

/* OPERADOR TERNÁRIO (ideal para condicionais menores)

nomeFilme === "Coringa"
  ? console.log("É o filme do Coringa")
  : console.log("É outro filme"); */
